# YISO-X
YISO-X 是基于 YISO 的 Fork 版本，旨在提供更强大的搜索功能和更好的用户体验。

### 关于
YISO-X 是基于 YISO 的 Fork 版本，旨在提供更强大的搜索功能和更好的用户体验。
使用 MYSQL ,替换 BiuSQL 数据库。UI 更为简洁